-- write key/value via POST
if request.method ~= "POST" then return "Invalid method" end
local k = request.query.key
local v = request.query.value
if not k or not v then return "Missing key or value" end
sqlite_query("/tmp/microbean.db", string.format("INSERT OR REPLACE INTO kv (key, value) VALUES ('%s','%s')", k, v))
return "Saved " .. k
