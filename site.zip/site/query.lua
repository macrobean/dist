-- query by key in sqlite
local key = request.query.key
if not key then return "Missing key parameter" end
local res = sqlite_query("/tmp/macrobean.db", "SELECT value FROM kv WHERE key='"..key.."'")
return res[1] and res[1].value or "Not found"