function match_route(pattern, path)
  local param_names = {}
  local lua_pattern = "^" .. pattern:gsub(":[^/]+", function(p)
    table.insert(param_names, p:sub(2))
    return "([^/]+)"
  end) .. "$"
  local matches = { string.match(path, lua_pattern)}
  if #matches == 0 then return nil end
  local params = {}
  for i, name in ipairs(param_names) do
    params[name] = matches[i]
  end
  return params
end

routes = {}
dynamic_routes = {}

function route(pattern, handler)
  table.insert(dynamic_routes, { pattern = pattern, handler = handler })
end

function find_route(path)
  for _, r in ipairs(dynamic_routes) do
    local params = match_route(r.pattern, path)
    if params then return r.handler, params end
  end
  return nil, nil
end

-- Auth middleware
routes.before = function()
  if request.query.secret ~= "opensesame" then
    return "Access denied. Use ?secret=opensesame"
  end
end

-- Dynamic pattern handlers
route("/hello/:name", function()
  return "Hi, " .. (request.params.name or "unknown")
end)

route("/add/:x/:y", function()
  local x = tonumber(request.params.x)
  local y = tonumber(request.params.y)
  return tostring(x + y)
end)

route("/secret/:word", function()
  return "Shh... your spell was: " .. request.params.word
end)

-- JSON info route
route("/api/info", function()
  local json = {
    path = request.path,
    method = request.method,
    db_enabled = (use_db and true) or false,
    lua_enabled = (use_lua and true) or false,
    files = zip_contents,
  }
  local encode = function(tbl)
    local s = "{" for k,v in pairs(tbl) do
      s = s .. string.format('"%s":"%s",', tostring(k), tostring(v)) end
    return s:sub(1, -2) .. "}"
  end
  return encode(json)
end)
route("/query.lua", function()
  return dofile("site/query.lua")
end)